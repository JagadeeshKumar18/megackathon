
import org.bytedeco.javacv.*;
import org.bytedeco.opencv.opencv_core.*;
import org.bytedeco.opencv.opencv_imgproc.*;
import org.bytedeco.opencv.opencv_videoio.*;

import java.util.*;

public class YogaInstructor {

    private static VideoCapture initCam() {
        VideoCapture cam = new VideoCapture(0);
        cam.set(Videoio.CAP_PROP_AUTOFOCUS, 0);
        cam.set(Videoio.CAP_PROP_FRAME_WIDTH, 1280);
        cam.set(Videoio.CAP_PROP_FRAME_HEIGHT, 720);
        return cam;
    }

    public static double calculateAngle(double[] p1, double[] p2, double[] p3) {
        if (p1 == null || p2 == null || p3 == null) return -1; // Error handling
        double radians = Math.atan2(p3[1] - p2[1], p3[0] - p2[0]) - Math.atan2(p1[1] - p2[1], p1[0] - p2[0]);
        double angle = Math.abs(radians * 180.0 / Math.PI);
        return angle > 180 ? 360 - angle : angle;
    }

    public static List<Double> extractLandmarks(Mat image) {
        // Simulate landmark extraction by generating random points
        List<Double> landmarks = new ArrayList<>();
        for (int i = 0; i < 33; i++) {
            landmarks.add(Math.random()); // Simulated x
            landmarks.add(Math.random()); // Simulated y
            landmarks.add(Math.random()); // Simulated z
            landmarks.add(Math.random()); // Simulated visibility
        }
        return landmarks;
    }

    public static List<String> checkPoseAngles(int poseIndex, double[] angles, Map<Integer, Map<String, Double>> thresholds) {
        List<String> feedback = new ArrayList<>();
        for (String joint : thresholds.get(poseIndex).keySet()) {
            double threshold = thresholds.get(poseIndex).get(joint);
            if (Math.abs(angles[poseIndex] - threshold) > 20) {
                feedback.add("Adjust your " + joint);
            }
        }
        return feedback.isEmpty() ? Collections.singletonList("Great job! Your pose looks good.") : feedback;
    }

    public static void main(String[] args) {
        VideoCapture cam = initCam();
        Mat image = new Mat();

        // Simulated threshold data for angles
        Map<Integer, Map<String, Double>> thresholds = new HashMap<>();
        thresholds.put(0, Map.of("elbow_left", 150.0, "elbow_right", 150.0)); // Add more as needed

        while (true) {
            if (!cam.read(image)) break;
            Mat flipped = new Mat();
            flip(image, flipped, 1);
            Mat resizedImage = new Mat();
            resize(flipped, resizedImage, new Size(640, 360), 0, 0, INTER_AREA);

            // Extract landmarks from the image
            List<Double> landmarks = extractLandmarks(resizedImage);
            double[] angles = new double[1]; // Placeholder for angle calculations

            // Calculate angles based on the landmarks
            angles[0] = calculateAngle(new double[]{landmarks.get(2), landmarks.get(3)},
                                        new double[]{landmarks.get(0), landmarks.get(1)},
                                        new double[]{landmarks.get(4), landmarks.get(5)});

            // Check pose angles and provide feedback
            List<String> feedback = checkPoseAngles(0, angles, thresholds);
            feedback.forEach(System.out::println);

            // Display the image
            imshow("Yoga Pose Detection", flipped);
            if (waitKey(1) == 'q') break;
        }

        cam.release();
    }
}
